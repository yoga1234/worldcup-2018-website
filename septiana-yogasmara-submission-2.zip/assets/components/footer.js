const FOOTER = `
  <footer class="page-footer blue lighten-1">
    <div class="footer-copyright">
      <div class="container">
        &copy World Cup 2018 Website By Yogasmara
      </div>
    </div>
  </footer>
`;

export default FOOTER;